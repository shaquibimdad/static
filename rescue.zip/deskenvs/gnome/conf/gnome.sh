# backup all gnome settings
dconf dump / > gnome.conf