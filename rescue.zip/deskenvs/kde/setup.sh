#!/bin/bash
echo "Loading KDE config..."


