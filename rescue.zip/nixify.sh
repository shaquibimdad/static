#!/bin/bash

# logging
log() {
    local message=$1
    local color=$2
    local style=$3
    local color_code="\e[${color}m"
    local style_code="\e[${style}m"
    local reset_code="\e[0m"
    echo -e "${style_code}${color_code}${message}${reset_code}"
}

run_as_root() {
    if command -v sudo >/dev/null 2>&1; then
        sudo "$@"
    else
        log "Error sudo not available" 31 1
        exit 1
    fi
}

if ! run_as_root echo ''; then
    log "Error: Permission Denied" 31 1
    exit 1
else
    log "Sudo granted" 32 1
fi

# gitconfig
git config --global user.name "shaquibimdad"
git config --global user.email "shaquibxyz@gmail.com"
git config --global user.signingkey "shaquibxyz@gmail.com"
git config --global commit.gpgsign true
git config --global gpg.program "gpg2"
git config --global core.editor "nano"
git config --global init.defaultBranch "main"
git config --global pull.rebase true
git config --global pull.ff only
git config --global push.default current
git config --global merge.tool meld
log "gitconfig setup complete" 32 1


# link config files

create_symlinks() {
    local source_dir=$1
    local target_dir=$2
    if [ -L "$target_dir" ]; then
        log "Removing existing symlink: $target_dir" 33 1
        rm "$target_dir"
    elif [ -e "$target_dir" ]; then
        log "Removing existing folder: $target_dir" 33 1
        rm -rf "$target_dir"
    fi
    ln -s "$source_dir"/* "$target_dir"
}

create_symlinks "$(pwd)/configs/fish" ~/.config/fish
create_symlinks "$(pwd)/configs/kitty" ~/.config/kitty

rm ~/.yarnrc && ln -s $(pwd)/configs/yarn/.yarnrc ~/

log "Config files linked" 32 1

# fstab entry for my data partition
if [ ! -e "/dev/nvme0n1p3" ]; then
    log "Error: /dev/nvme0n1p3 does not exist. Please check the partition" 31 1
elif [ -e "/media/shaquib" ]; then
    log "Error: /media/shaquib already exists and mounted. Skipping" 31 1
else
    log "Creating /media/shaquib and setting permissions..." 32 1
    run_as_root mkdir -p /media/shaquib
    run_as_root chown -R shaquibimdad:shaquibimdad /media/shaquib
    run_as_root echo "/dev/nvme0n1p3 /media/shaquib ntfs-3g auto,users,permissions,exec,uid=1000,gid=1000,dmask=022,fmask=022 0 0" | sudo tee -a /etc/fstab
fi
log "fstab entry for my data partition setup complete" 32 1

# change shell to fish
run_as_root usermod -s /usr/bin/fish shaquibimdad
log "Shell changed to fish" 32 1

# install yay aur helper and packages
if ! command -v yay >/dev/null 2>&1; then
    log "Installing yay aur helper..." 32 1
    git clone https://aur.archlinux.org/yay.git --depth 1 && cd yay && makepkg -si --noconfirm && cd .. && rm -rf yay
else
    log "Yay is already installed. Skipping installation." 32 1
fi

yay -Sy --needed --noconfirm \
    nautilus-open-any-terminal \
    google-chrome \
    visual-studio-code-bin

log "Yay aur helper and package installation complete" 32 1

desktop environment specific
if [ "$XDG_CURRENT_DESKTOP" = "KDE" ]; then
    log "Setting up KDE config..." 32 1
    source deskenvs/kde/setup.sh
elif [ "$XDG_CURRENT_DESKTOP" = "GNOME" ]; then
    log "GNOME detected..." 32 1
    source deskenvs/gnome/setup.sh
else
    log "Error: Desktop environment not KDE or GNOME" 31 1
    exit 1
fi

# install fisher
# bash -c 'fish -c "curl -sL https://raw.githubusercontent.com/jorgebucaran/fisher/main/functions/fisher.fish | source && fisher install jorgebucaran/fisher"'
# # install fish plugins
# bash -c 'fish -c "fisher install IlanCosman/tide@v5"'
# log "Fisher and plugins installed" 32 1

